PK01 - Quake IV texture set by Philip Klevestav
www.philipk.net | philipk@philipk.net

***

Howto install:
Simply unzip to the q4base folder for the Quake IV game you want to build a map for.
For instance: "C:\quake4\q4nase".

***

This set was meant to be larger but due to lack of time and a bit of
lost interest for this set I decided to release it as it is now.
Some stuff should have been tweaked more but as I said 
I won't and will just release it in it's current state instead.
I sure will try to release more sets in the future tho.

This set was created for Quake IV originally and was ported to Source as well.
If you want the Source version goto: www.philipk.net.

***

Feel free to edit the textures and make additions in any way that suits you.
Have fun.

Thanks to mnemjc for fixing some broken materials!