URL:
 https://opengameart.org/content/space-ships-brute
 https://opengameart.org/sites/default/files/space_ships_pack4-1_0.zip

License: 
 CC0
  http://creativecommons.org/publicdomain/zero/1.0/

Authors:
 Commander
  https://opengameart.org/users/commander
  https://www.indiedb.com/members/bazlik-commander

Copyright/Attribution Notice: 
 Created by Bazlik_Commander

Origin:
 These sprites were made for the game
  "Galactic Battles SandBox 4 Extreme"
  made by Bazlik_Commander,
  available for download on IndieDB:
   https://www.indiedb.com/games/galactic-battles-sandbox-4-extreme

Changelog:
 * Original sprites by Bazlik_Commander
 * Rework to adapt it to SDL2 by Florent Monnier:
   - Alpha merged with black,
   - Background in green or red for SDL2 transparent color key
   - Croped/Trimed to the edges of the sprites
   - Converted to BMP format (24 bits: R8 G8 B8)

New BMP Packs:
  https://opengameart.org/content/deep-space-ships-bmp
